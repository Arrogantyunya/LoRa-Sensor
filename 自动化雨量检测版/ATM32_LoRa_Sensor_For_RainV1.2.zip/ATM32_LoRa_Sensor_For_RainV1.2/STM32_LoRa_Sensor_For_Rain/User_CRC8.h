#ifndef _USER_CRC_H_
#define _USER_CRC_H_

typedef unsigned long  DWORD;
typedef unsigned short WORD;


unsigned char GetCrc8(unsigned char * data, int length);

#endif /*_USER_CRC_H_ */